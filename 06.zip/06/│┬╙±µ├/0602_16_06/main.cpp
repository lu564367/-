#include <stdio.h>
int main()
{
	int a[40]={1,1};
	int i;
	for(i=2;i<40;i++)
	{
		a[i]=a[i-2]+a[i-1];
	}

	int count=0;
	for(i=0;i<40;i++)
	{
		printf("%d\t",a[i]);
		count++;
		if(count%5==0)
		{
			printf("\n");
		}
	}
	return 0;
}