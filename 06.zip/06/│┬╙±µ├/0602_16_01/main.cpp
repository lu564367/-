#include <stdio.h>
int main()
{
	printf("1.B 2.C 3.5 4.D 5.D 6.B 7.D 8.B 9.B\n");

	return 0;
}