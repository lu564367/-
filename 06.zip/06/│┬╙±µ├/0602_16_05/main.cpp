#include <stdio.h>
int main()
{
	char a[13]={'I',' ','a','m',' ','Y','o','u','r','N','a','m','e'};

	for(int i=0;i<13;i++)
	{
		printf("%c\n",a[i]);
	}
	return 0;
}