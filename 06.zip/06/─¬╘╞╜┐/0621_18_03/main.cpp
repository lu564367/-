#include "stdio.h"
int main()
{
	int a[5]={12, 23, -55, 89, -6},sum=0;
	for(int i=0;i<5;i++)
	{
		sum+=a[i];
	}
	printf("%d\n",sum);
	return 0;
}
		