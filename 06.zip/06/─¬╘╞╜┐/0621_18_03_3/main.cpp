#include "stdio.h"
int main()
{
	double a[10],b=0,sum=0,ave=0;
	for(int i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
	}
	for(i=0;i<10;i++)
	{
		b=a[i]*0.1;
		printf("��%d��������%lf\n",i,b);
		sum+=b;
		
	}
	printf("�ܳɼ�Ϊ%lf\n",sum*10);
	ave=sum*10/10;
	printf("ƽ��ֵΪ%lf\n",ave);
	return 0;
}


