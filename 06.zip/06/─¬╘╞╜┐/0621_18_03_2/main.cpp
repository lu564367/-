#include "stdio.h"
int main()
{
	double a[10],sum=0,ave=0;
	for(int i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
	}
	for(i=0;i<10;i++)
	{
		printf("%lf ",a[i]);
		sum+=a[i];
	}
	printf("\n");
	ave=sum/10;
	printf("%lf\n",ave);
	return 0;
}
