#include "stdio.h"
int main()
{
	int a[20]={1,2,3,4,5,6,7,8,9,10},count=0;
	for(int i=10;i<20;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<20;i++)
	{
		count+=1;
		printf("%d ",a[i]);
		if(count%5==0)
	{
		printf("\n");
	}
	}
	return 0;
}
	



