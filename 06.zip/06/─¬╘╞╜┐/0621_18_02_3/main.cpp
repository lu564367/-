#include "stdio.h"
int main()
{
	double a[10];
	for(int i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
	}
	for(i=19;i<=0;i--)
	{
		printf("%lf ",a[i]);
	}
	return 0;
}