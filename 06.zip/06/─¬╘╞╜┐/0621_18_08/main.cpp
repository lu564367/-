#include "stdio.h"
int main()
{
	double a[20];
	for(int i=0;i<20;i++)
	{
		scanf("%lf",a[i]);
	}
	double max=a[0],min=a[0],sum=0;
	for(i=0;i<20;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
		}
		if(a[i]<min)
		{
			min=a[i];
		}
		sum+=a[i];
	}
	printf("ƽ����Ϊ%lf\n��߷�Ϊ%lf\n��ͷ�Ϊ%lf\n",sum/20,max,min);
	return 0;
}
