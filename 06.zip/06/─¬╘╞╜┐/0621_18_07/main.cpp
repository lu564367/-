#include "stdio.h"
int main()
{
	int a[10];
	for(int i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	int min=a[0],index=0;
	for(i=0;i<10;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			index=i;
		}
	}
	printf("��СֵΪ%d,λ��Ϊ%d\n",min,index);
	return 0;
}
