#include "stdio.h"
int main()
{
	char a[]={'I',' ','a','m',' ','M','Y','J'};
	for(int i=0;i<8;i++)
	{
		printf("%c",a[i]);
	}
	printf("\n");
	return 0;
}