#include "stdio.h"
int main()
{
	int a[40]={1,1};
	for(int i=0;i<40;i++)
	{
		a[i+2]=a[i]+a[i+1];
		printf("%d ",a[i]);
	}
	return 0;
}