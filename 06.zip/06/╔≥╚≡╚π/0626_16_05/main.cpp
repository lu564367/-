#include <stdio.h>
int main()
{
	
	char str[]={'I',' ','a','m',' ','y','o','u','r',' ','n','a','m','e'};
	for(int i=0;i<14;i++)
	{
		printf("%c",str[i]);
	}
	printf("\n");
	return 0;
}
