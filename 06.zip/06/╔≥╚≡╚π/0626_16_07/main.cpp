#include <stdio.h>
int main()
{
	int a[10]={3,7,5,4,9,1,2,8,6,0};
	int min,index;
	min=a[0];
	index=0;
	int i;
	for(i=1;i<=10-1;i++)
	{
		if(a[i]<min)
		{
			min=a[i];
			index=i;
		}
	}
	printf("��СֵΪ��%d\n",min);
	printf("λ���±꣺%d\n",index);
	return 0;
}