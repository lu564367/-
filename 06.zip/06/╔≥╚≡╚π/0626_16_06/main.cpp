#include <stdio.h>
#define NUM 40
int main()
{
	int f[NUM]={1,1};
	int i;
	      for(i=2;i<NUM;i++)
		  {
	         f[i]=f[i-2]+f[i-1];
		  }

		for(i=0;i<NUM;i++)
		{
			printf("%8d",f[i]);

		}
	
		printf("\n");
		return 0;
}