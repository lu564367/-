#include <stdio.h>
int main()
{
	double a[10];
	
	int i;
	for(i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
	}
	double sum=0,aa;
	for(i=0;i<10;i++)
	{
		printf("�������Ϊ��%.2lf\n",a[i]);
		sum=sum+a[i];
	}
	aa=sum/10;
	printf("ƽ��ֵΪ:%.2lf\n",aa);
	return 0;
}


