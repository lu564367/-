#include <stdio.h>
int main()
{
	double a[10];

	printf("������10λͬѧ�ĳɼ�(0.0-100,0):");
	int i;
	for(i=0;i<10;i++)
	{
		scanf("%lf",&a[i]);
	}
	double n;
	for(i=0;i<10;i++)
	{

		n=a[i]*0.1;
		printf("ÿ��Ԫ�س�0.1:%lf\n",n);
	}
	double x=0,y;
	for(i=0;i<10;i++)
	{
		x=x+a[i];
	}
	y=x/10;
	printf("�ܳɼ�Ϊ��%lf ƽ��ֵΪ:%lf\n",x,y);

	return 0;
}