#include <stdio.h>
int main()
{
	printf("1.D  2.C 3. 378 4.D  5.D  6.C  7.D  8.B  9.B ");
	return 0;
}
