#include <stdio.h>
int main()
{
	int a[5]={12,23,-55,89,-6};

	int sum =0;
    int i;
	for(i=0;i<5;i++)
	{
		printf("��%d��Ϊ%d\n",i,a[i]);
	}
	for( i=0;i<5;i++)
	{
		sum=sum+a[i];
	}
	printf("��Ϊ%d\n",sum);
	return 0;
}
