#include <stdio.h>
int main()
{
int a[10]={3,7,5,4,9,1,2,8,6,0};
	int max,index;
	max=a[0];
	index=0;
	int i;
	for(i=1;i<=10-1;i++)
	{
		if(a[i]>max)
		{
			max=a[i];
			index=i;
		}
	}
        double sum=0,aa;
    	for(i=0;i<10;i++)
	{
		
		sum=sum+a[i];
	}
	aa=sum/10;
	printf("ƽ��ֵΪ:%.2lf\n",aa);
	printf("���ֵΪ��%d\n",max);
	printf("λ���±꣺%d\n",index);
	return 0;
}