
#include <stdio.h>
int main()
{
	int x[10]={1,2,3,4,5,6,7,8,9,10},b[10];
	
	int i;
	for(i=0;i<10;i++)
	{
		b[i]=x[10-i-1];
		printf("��%d��Ϊ%d\n",i,b[i]);
	}
	for(i=0;i<10;i++)
	{
		x[i]=b[i];
	}
	for(i=0;i<10;i++)
	{
		printf("%4d",x[i]);
	}
	return 0;
}