#include <stdio.h>
int main()
{
	int x[10]={21,45,38,66,73,14,55,99,85,10};
	
	int i;
	for(i=0;i<10;i++)
	{
		printf("��%d��Ϊ%d\n",i,x[i]);
	}

	return 0;
}