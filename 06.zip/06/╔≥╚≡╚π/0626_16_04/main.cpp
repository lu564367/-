#include <stdio.h>
#define NUM 20
int main()
{
	int a[20]={1,2,3,4,5,6,7,8,9,10};
	printf("�����10��Ԫ��Ϊ��");
	int i;
	for(i=0;i<10;i++)
	{
		scanf("%d",&a[i]);
	}
	int count=0;
	for(i=0;i<20;i++)
	{
		printf("%d\t",a[i]);
        count++;
		if(count%5==0)
		{
			printf("\n");
		}
	}
	return 0;
}