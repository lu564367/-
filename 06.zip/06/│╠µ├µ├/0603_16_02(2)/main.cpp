#include"stdio.h"
int main()

{
	printf("������Ԫ��");
	int a[10];
	scanf("%d",&a[0]);
	scanf("%d",&a[1]);
    scanf("%d",&a[2]);
    scanf("%d",&a[3]);
    scanf("%d",&a[4]);
    scanf("%d",&a[5]);
    scanf("%d",&a[6]);
    scanf("%d",&a[7]);
    scanf("%d",&a[8]);
    scanf("%d",&a[9]);
	for(int i=0;i<10;i++)
	{
		printf("��%d��Ԫ��Ϊ%d\n",i,a[i]);
	}
	return 0;
	}