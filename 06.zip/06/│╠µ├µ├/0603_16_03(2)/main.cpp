#include"stdio.h"
int main()
{
	double x[10];
	double sum=0;
	float average=1;
	scanf("%lf",&x[0]);
	scanf("%lf",&x[1]);
	scanf("%lf",&x[2]);
	scanf("%lf",&x[3]);
    scanf("%lf",&x[4]);
	scanf("%lf",&x[5]);
	scanf("%lf",&x[6]);
	scanf("%lf",&x[7]);
    scanf("%lf",&x[8]);
	scanf("%lf",&x[9]);

	for(int i=0;i<10;i++)
	{
		printf("��%d��Ԫ��Ϊ%.2lf\n",i,x[i]);
        sum=sum+x[i];
		average=sum/i;
	}
	printf("ƽ��ֵΪ%.lf\n",average);
	return 0;
}
	
