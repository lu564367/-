#include"stdio.h"
int main()
{
	double a[10];
	double sum=0,average=0;
	scanf("%lf",&a[0]);
	scanf("%lf",&a[1]);
	scanf("%lf",&a[2]);
	scanf("%lf",&a[3]);
	scanf("%lf",&a[4]);
	scanf("%lf",&a[5]);
	scanf("%lf",&a[6]);
	scanf("%lf",&a[7]);
	scanf("%lf",&a[8]);
	scanf("%lf",&a[9]);

	for( int i=0;i<10;i++)
	{
		a[i]=a[i]*0.1;
		printf("��%d��Ԫ��Ϊ%.2lf\n",i,a[i]);
		sum=sum+a[i];
	    average=sum/i;
	}

	printf("�ܳɼ�Ϊ%lf\n",sum);
	printf("ƽ��ֵΪ%lf\n",average);
	return 0;
}
