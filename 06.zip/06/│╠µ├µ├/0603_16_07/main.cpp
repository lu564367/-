#include"stdio.h"
int main()
{
	int d [10]={1,12,13,4,5,6,7,34,78,23};

	int min,index;
	min=d[0];
	index=0;

	for(int i=0;i<10;i++)
	{
		if(d[i]<min)
		{
		min=d[i];
		index=0;
		}
	}
	printf("��Сֵ��%d\n",min);
	printf("λ���±�%d\n",index);
	return 0;
}
