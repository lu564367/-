#include"stdio.h"
#define NUM 40
int main()
{
	int f [NUM]={1,1};

	for(int i=2;i<40;i++)
	{
		f[i]=f[i-2]+f[i-1];
	}
	for(i=0;i<NUM;i++)
	{
		printf("%10d",f[i]);
		if((i+1)%5==0)
		{
			printf("\n");
		}
	}

	printf("\n");
	return 0;
}
