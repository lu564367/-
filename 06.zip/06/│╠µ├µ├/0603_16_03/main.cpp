#include"stdio.h"
int main()

{
	int sum=0;
	int a[5]={12,23,-55,89,-6};

	for(int i=0;i<5;i++)
	{
		printf("��%d��Ԫ��Ϊ%d\n",i,a[i]);
	    sum=sum+a[i];
	}
	printf("��Ϊ%d\n",sum);
	return 0;
}