#include"stdio.h"
int main()
{

	int a[10]={21,45,38,66,73,14,55,99,85,10};

	for(int i=0;i<10;i++)
	{
		printf("��%d��Ԫ��Ϊ%d\n",i,a[i]);
	}
	return 0;
}