#include"stdio.h"
int main()
{
	double d[20]={87,98,67,89,77,91,72,94,84,81,79,75,78,86,59,78,67,89,76,76};
	double sum=0,max,min,average=0;
	max=d[0];
	min=d[0];

	for(int i=0;i<20;i++)
	{
		if(d[i]>max)
		{
			max=d[i];
		}
		if(d[i]<min)
		{
			min=d[i];
		}
		sum=sum+d[i];
		average=sum/i;
	}
	printf("ƽ��ֵΪ%.2lf\n",average);
	printf("��߷�Ϊ%.2lf\n",max);
	printf("��ͷ�Ϊ%.2lf\n",min);
	return 0;
}
