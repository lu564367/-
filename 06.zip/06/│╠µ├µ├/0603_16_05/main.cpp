#include"stdio.h"

#define I am YourName
int main()
{
	char a[13]={'I',' ','a','m',' ','C','T','T'};

	for(int i=0;i<13;i++)
	{
		printf("%c",a[i]);
	}
	return 0;
}


